#!/bin/bash
Rscript data_pipe.R
