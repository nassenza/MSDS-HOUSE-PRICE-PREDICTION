This folder contains exploratory data analysis performed independently by the analysts. 
